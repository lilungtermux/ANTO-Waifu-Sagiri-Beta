# ANTO Waifu — Sagiri Sprite Edition

Prototype floating Android companion with a generated Sagiri sprite, drag movement, tap response, and gentle bobbing animation.

Build/import the project in Code On The Go or Android Studio, Gradle sync, then Build APK. Install `app-debug.apk`, open app, grant display-over-other-apps permission, and tap Tampilkan Sagiri.

This is sprite animation, not real Live2D rigging yet.
