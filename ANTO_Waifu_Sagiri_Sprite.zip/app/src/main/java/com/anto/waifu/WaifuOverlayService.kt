package com.anto.waifu
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import kotlin.math.abs
class WaifuOverlayService:Service(){
 private lateinit var wm:WindowManager; private lateinit var img:ImageView; private lateinit var lp:WindowManager.LayoutParams
 override fun onCreate(){ super.onCreate(); wm=getSystemService(WINDOW_SERVICE) as WindowManager
  img=ImageView(this).apply { setImageResource(R.drawable.sagiri_floating); scaleType=ImageView.ScaleType.FIT_CENTER; contentDescription="Sagiri floating waifu" }
  lp=WindowManager.LayoutParams(300,850,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START;x=0;y=80}
  img.setOnTouchListener(object:android.view.View.OnTouchListener{var sx=0;var sy=0;var px=0;var py=0;var dragged=false
   override fun onTouch(v:android.view.View,e:MotionEvent):Boolean{ when(e.action){ MotionEvent.ACTION_DOWN->{sx=e.rawX.toInt();sy=e.rawY.toInt();px=lp.x;py=lp.y;dragged=false;return true}
    MotionEvent.ACTION_MOVE->{val dx=e.rawX.toInt()-sx;val dy=e.rawY.toInt()-sy;if(abs(dx)+abs(dy)>8)dragged=true;lp.x=px+dx;lp.y=py+dy;wm.updateViewLayout(img,lp);return true}
    MotionEvent.ACTION_UP->{if(!dragged){Toast.makeText(this@WaifuOverlayService,"Hai ayang! Sagiri di sini 💙",Toast.LENGTH_SHORT).show();img.animate().scaleX(1.06f).scaleY(1.06f).setDuration(150).withEndAction{img.animate().scaleX(1f).scaleY(1f).setDuration(150).start()}.start()};return true} };return false }
  })
  wm.addView(img,lp); bob()
 }
 private fun bob(){ if(!::img.isInitialized)return; img.animate().translationY(-10f).setDuration(850).withEndAction{img.animate().translationY(10f).setDuration(850).withEndAction{bob()}.start()}.start() }
 override fun onDestroy(){if(::img.isInitialized){img.animate().cancel();try{wm.removeView(img)}catch(_:Exception){}};super.onDestroy()}
 override fun onBind(intent:Intent?):IBinder?=null
}
