package com.anto.waifu
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
class MainActivity : Activity() {
 private val requestCode=1001
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(32,48,32,32) }
  layout.addView(TextView(this).apply { text="ANTO Waifu 💙\nSagiri Sprite Edition"; textSize=25f })
  layout.addView(TextView(this).apply { text="\nFloating Sagiri prototype\nDrag to move • Tap to interact\n"; textSize=16f })
  layout.addView(Button(this).apply { text="Tampilkan Sagiri"; setOnClickListener { startWaifu() } })
  layout.addView(Button(this).apply { text="Sembunyikan Sagiri"; setOnClickListener { stopService(Intent(this@MainActivity,WaifuOverlayService::class.java)) } })
  layout.addView(Button(this).apply { text="Buka izin overlay"; setOnClickListener { startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),requestCode) } })
  setContentView(layout)
 }
 private fun startWaifu(){ if(!Settings.canDrawOverlays(this)){ startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")),requestCode); return }; startService(Intent(this,WaifuOverlayService::class.java)) }
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==this.requestCode && Settings.canDrawOverlays(this)) startWaifu() }
}
