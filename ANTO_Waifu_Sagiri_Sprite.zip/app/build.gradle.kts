plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.anto.waifu"; compileSdk = 35
 defaultConfig { applicationId = "com.anto.waifu"; minSdk = 26; targetSdk = 28; versionCode = 2; versionName = "1.1" } }
